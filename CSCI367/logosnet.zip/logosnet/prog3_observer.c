
/* Ryan Lingg, Chris White
* CSCI 367 Computer Networks 1
* Project 3: LogosNet
* 11/27/18
* prog3_observer.c
*/

#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>

#include "prog3_observer.h"

/* Macro Definitions */
#define FALSE 0   /* boolean replacement */
#define TRUE 1    /* boolean replacement */
#define BLEN 1000 /* message buffer length */

/* Global Connection Parameters */
struct hostent *ptrh;   /* pointer to a host table entry */
struct protoent *ptrp;  /* pointer to a protocol table entry */
struct sockaddr_in sad; /* structure to hold an IP address */
int sd;                 /* socket descriptor */
int port;               /* protocol port number */
char *host;             /* pointer to host name */
int n;                  /* number of characters read */
char buf[BLEN];         /* buffer for data from the server */

int main(int argc, char **argv)
{

    // TODO(validArguments): Check command line arguments
    if (validArguments(argc, argv) == FALSE) {
      exit(EXIT_FAILURE);
    }

    // Initialize the socket structure and connect to the chat server
    initSocketAndConnect(argc, argv);

    // Define participant to observe

    // Observe Messages
}

/* Initialize Socket and Connect to Server
 *
 * Fills all the fields of the socket structure and connects to the server.
 */
void initSocketAndConnect(int argc, char **argv)
{
    memset((char *)&sad, 0, sizeof(sad)); /* clear sockaddr structure */
    sad.sin_family = AF_INET;             /* set family to Internet */

    if (argc != 3)
    {
        fprintf(stderr, "Error: Wrong number of arguments\n");
        fprintf(stderr, "usage:\n");
        fprintf(stderr, "./client server_address server_port\n");
        exit(EXIT_FAILURE);
    }

    port = atoi(argv[2]); /* convert to binary */
    if (port > 0)
    { /* test for legal value */
        sad.sin_port = htons((u_short)port);
    }
    else
    {
        fprintf(stderr, "Error: bad port number %s\n", argv[2]);
        exit(EXIT_FAILURE);
    }

    host = argv[1]; /* if host argument specified */

    /* Convert host name to equivalent IP address and copy to sad. */
    ptrh = gethostbyname(host);
    if (ptrh == NULL)
    {
        fprintf(stderr, "Error: Invalid host: %s\n", host);
        exit(EXIT_FAILURE);
    }

    memcpy(&sad.sin_addr, ptrh->h_addr, ptrh->h_length);

    /* Map TCP transport protocol name to protocol number. */
    if (((long int)(ptrp = getprotobyname("tcp"))) == 0)
    {
        fprintf(stderr, "Error: Cannot map \"tcp\" to protocol number");
        exit(EXIT_FAILURE);
    }

    /* Create a socket. */
    sd = socket(PF_INET, SOCK_STREAM, ptrp->p_proto);
    if (sd < 0)
    {
        fprintf(stderr, "Error: Socket creation failed\n");
        exit(EXIT_FAILURE);
    }

    /* TODO(connect): Connect the socket to the specified server. You have to pass correct parameters to the connect function.*/
    if (connect(sd, (struct sockaddr *)&sad, sizeof(sad)) < 0)
    {
        fprintf(stderr, "connect failed\n");
        exit(EXIT_FAILURE);
    }
}

/* Valid Arguments Checker
 *
 * Makes sure the command line arguments entered are valid for this program.
 */
int validArguments(const int numArgs, char **args)
{
    int argsValid = TRUE;
    if (numArgs != 3)
    {
        fprintf(stderr, "Usage: ./observer_program server_ip observer_port\n");
        argsValid = FALSE;
    }
    return argsValid;
}
