
/* Ryan Lingg, Chris White
* CSCI 367 Computer Networks 1
* Project 3: LogosNet
* 11/27/18
* prog3_server.c
*/

#include <ctype.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>

#include "prog3_server.h"

/* Macro Definitions */
#define FALSE 0   /* boolean replacement */
#define TRUE 1    /* boolean replacement */
#define QLEN 6    /* size of request queue */
#define MAXACTIVE 255 /* short message and board size length */
#define BLEN 1000 /* message buffer length */

/*------------------------------------------------------------------------
* Program: prog3_server
*
* Purpose: allocate a socket and then run chatroom server
*
* Syntax: ./prog2_server server_port
*
* server_port       - protocol port number server is using
*
*------------------------------------------------------------------------
*/

/* Global Variables */
struct protoent *ptrp; /* pointer to a protocol table entry */
int optval = TRUE;     /* boolean value when we set socket option */
int username_timeout = 10; /*amount of time a user has to enter their username (seconds)*/
int max_fd;

/*  */
fd_set active_sockets;
struct ConnectionStatsNode** connectionsList = NULL;
int numParticipants = 0;
int numObservers = 0;

/* Global Participant Socket Parameters */
struct sockaddr_in sad_p; /* structure to hold a participant's address */
struct sockaddr_in cad_p; /* structure to hold client's address */
int sd_p;                 /* server socket descriptor for clients */
int port_p;               /* protocol port number */
int alen_p;               /* length of address' */

/* Global Observer Socket Parameters */
struct sockaddr_in sad_o; /* structure to hold a observer's address */
struct sockaddr_in cad_o; /* structure to hold client's address */
int sd_o;                 /* server socket descriptor for observers */
int port_o;               /* protocol port number */
int alen_o;               /* length of address' */

/* Global Connection Parameters */
int n = 0; /* number of bytes received in last message */
char buf[BLEN];

/********************** Main Function **********************/

int main(int argc, char **argv)
{
  fprintf(stdout, "\nLogosNet server starting!\n");

  // TODO(validArguments): Check command line arguments
  if (validArguments(argc, argv) == FALSE) {
    exit(EXIT_FAILURE);
  }

  // TODO(initSocketsAndListen): Initialize participant and observer socket structure, prepare for connections
  initSocketsAndListen(argv);


  // DATA STRUCTURE NEEDS:
  //   - List of active participants usernames to check for uniqueness and observers
  //   - Coordination between the user

  /*** LogosNet Participant Connection Code ***/

  // P0) Participant Connects

  // P1) Check number of participants
  // P1_Termination) 255 participants already connected, so send 'N' and close the socket
  // P2) Less than 255 participants, so send 'Y'

  // P3) Participant has 10 seconds to send their username
  //        Format: (uint8_t)length followed by (char[])username
  // P3_Termination) If they dont respond in 10 seconds close the connection

  // P4) If they send a username, check the validity and uniqueness
  // P4_A0) If the username is not valid, send user 'I' and waits for
  //        another username BUT does not reset the timer
  // P4_B0) If the username is already taken, send user 'T' and waits for
  //        another username AND the timer is reset to 10 seconds
  // P4_Termination) If a valid username is not recieved before the
  //                 timer ends then close the connection.

  // P5) The username is valid, send user 'Y'

  // P6) Add the participant to the pool of active chatters, add them to the
  //        list of active chatters, and declare that they have entered the chat room

  /*** LogosNet Observer Connection Code ***/

  // P0) Observer Connects

  // P1) Check number of observers
  // P1_Termination) 255 observers already connected, so nest 'N' and close the socket
  // P2) Less than 255 observers, so send 'Y'

  // P3) Observer has 10 seconds to send the username of the chatter they want to affiliate with
  //        Format: (uint8_t)length followed by (char[])username
  // P3_Termination) If they dont respond in 10 seconds close the connection

  // P4) If they send a username, check the length and then
  //        check if the username is associated with an active participant
  // P4_B0) If the username is already associated with an observer, send user 'T' and waits for
  //        another username AND the timer is reset to 10 seconds
  // P4_Termination) If a username is recieved but there is no active participants with that username
  //                 send the observer a 'N' then disconnect them.

  // P5) The username is valid and not already being observed, send user 'Y' and add observer ti

  /********** MAIN SERVER LOOP CODE **********/
  clearMessageBuf();
  int socket_activity;

  //Initialize socket descriptor set
  FD_ZERO(&active_sockets);
  FD_SET(sd_p, &active_sockets);
  FD_SET(sd_o, &active_sockets);
  max_fd = max2ints(sd_p, sd_o);

  //Loop that handles one socket action type at a time
  while (1) {
    socket_activity = 0;

    // Determine if socket activity is on connections or participants
    printf("Waiting for activity!\n");
    socket_activity = select(max_fd+1, &active_sockets, NULL, NULL, NULL);
    if (socket_activity == -1) {
      errorMessageAndExit("Error in select.");
    } else { // Activity on one of the sockets:
      if (FD_ISSET(sd_p, &active_sockets)) {
        printf("Connecting participant!\n");
        connectChatter();
      } else if (FD_ISSET(sd_o, &active_sockets)) {
        //connectObserver();
      } else {
        //Chatters talking
        printf("Participants chatting!\n");

      }
    }
  }
}

/********************** HELPER FUNCTIONS BELOW **********************/

/*********** Communication Helpers ***********/

/*********** Connection Helpers ***********/

/* Connect To Players
*
* This function handles establishing the initial connection with all of the chatters
*/
void connectChatter() {
  //Chatter Connects:
  int sd_temp;
  if ((sd_temp = accept(sd_p, (struct sockaddr *)&cad_p, (socklen_t *)&alen_p)) < 0) {
    fprintf(stderr, "Error: Accept failed\n");
    exit(EXIT_FAILURE);
  }

  // Check if space for more chatters is available and send response
  char connectionValidMessage = 'Y';
  if (numParticipants <= MAXACTIVE) {
    send(sd_temp, &connectionValidMessage, sizeof(connectionValidMessage), 0);
  } else {
    connectionValidMessage = 'N';
    send(sd_temp, &connectionValidMessage, sizeof(connectionValidMessage), 0);
    close(sd_temp);
    return;
  }

  // Negotiate chatters username (TRUE => Valic) (FALSE => RanOutOfTime)
  if(getChatterUsername(sd_temp) == FALSE) {
    close(sd_temp);
  } else {
    // Add Chatter to list of active chatters and socket add to chatroom fd_set
    insertHead_connList(connectionsList, createConnNode(strndup(buf,strlen(buf)), sd_temp));
    max_fd = max2ints(max_fd, sd_temp);
    FD_SET(sd_temp, &active_sockets);
  }
}

char validUsername() {
  char* username = buf;
  char usernameStatus = 'Y';
  // Check Validity
  for (int i = 0; username[i] != '\0'; i++){
    if (!isalpha(username[i]) && !isdigit(username[i]) && !(username[i] == '_')) {
      usernameStatus = 'I';
    }
  }
  // Check if taken
  if (findUserSocket(connectionsList, username) > 0) {
    usernameStatus = 'T';
  }
  printf("Username Desired: %s : Status: %c\n", username, usernameStatus);
  return usernameStatus;
}


int getChatterUsername(int sd_temp) {
  struct timeval timeout;
  fd_set connecting_socket;
  int receivedMessage = 0;
  int usernameValid = FALSE;

  // Set input fd to receiving server socket
  FD_ZERO(&connecting_socket);
  FD_SET(sd_temp, &connecting_socket);

  // Set timeout limit
  timeout.tv_sec = username_timeout;
  timeout.tv_usec = 0;

  // Listen for username
  while (1) {
    receivedMessage = select(sd_temp+1, &connecting_socket, NULL, NULL, &timeout);

    if (receivedMessage == -1) {
      errorMessageAndExit("Error in select.");
    } else if (receivedMessage == 0) {
      //If no username was entered and timed out
      break;
    } else {
      // Input Recieved:
      uint8_t usernameLen;
      n = recv(sd_temp, &usernameLen, sizeof(usernameLen), 0);
      checkTransmissionError("Username Length Error");
      printf("userLen: %d\n", usernameLen);
      clearMessageBuf();
      n = recv(sd_temp, &buf, usernameLen, 0);
      checkTransmissionError("Username Error");

      // Check the username in question is valid and get the
      // character associated with its status ('Y', 'T', or 'I')
      char usernameStatus = validUsername();
      send(sd_temp, &usernameStatus, sizeof(usernameStatus), 0);
      if (usernameStatus == 'Y') {
        usernameValid = TRUE;
        break;
      } else if (usernameStatus == 'T') {
        timeout.tv_sec = username_timeout;
        timeout.tv_usec = 0;
      }
    }
  }
  return usernameValid;
}


void clearMessageBuf() {
  memset(buf, '\0', BLEN);
}

void checkTransmissionError(char* message) {
  if (n < 0){
    fprintf(stderr, "Error: Transmission error %s\n", message);
    exit(EXIT_FAILURE);
  }
}


void errorMessageAndExit(char* message) {
	fprintf(stderr, "Error: %s\n", message);
	exit(EXIT_FAILURE);
}
/* Initialize Socket and Listen
 *
 * Set up the participant and observer sockets to listen for connections.
 */
void initSocketsAndListen(char **argv)
{
  // TODO(clearSockets): Clear participant sockaddr structure
  memset((char *)&sad_p, 0, sizeof(sad_p));
  memset((char *)&sad_o, 0, sizeof(sad_o));

  // TODO(socketFam): Set sockets family to AF_INET
  sad_p.sin_family = AF_INET;
  sad_o.sin_family = AF_INET;

  // TODO(socketLIP): Set local IP addresses to listen to all IP addresses this server can assume. You can do it by using INADDR_ANY
  sad_p.sin_addr.s_addr = INADDR_ANY;
  sad_o.sin_addr.s_addr = INADDR_ANY;

  // TODO(socketPort): Get port number from command line.
  port_p = atoi(argv[1]);
  port_o = atoi(argv[2]);

  if ((port_p > 0) || (port_o > 0))
  {
    // Set port numbers for participant and observer ports. The data type is u_short
    sad_p.sin_port = htons(port_p);
    sad_o.sin_port = htons(port_o);
  }
  else
  { /* print error message and exit */
    fprintf(stderr, "Error: Bad port number. (%s or %s)\n", argv[1], argv[2]);
    exit(EXIT_FAILURE);
  }

  // TODO(MapTCP): Map TCP transport protocol name to protocol number
  if (((long int)(ptrp = getprotobyname("tcp"))) == 0)
  {
    fprintf(stderr, "Error: Cannot map \"tcp\" to protocol number");
    exit(EXIT_FAILURE);
  }

  // TODO(socketCreate): Create a socket with AF_INET as domain, protocol type as SOCK_STREAM, and protocol as ptrp->p_proto. This call returns a socket descriptor named sd.
  sd_p = socket(AF_INET, SOCK_STREAM, ptrp->p_proto);
  sd_o = socket(AF_INET, SOCK_STREAM, ptrp->p_proto);
  if ((sd_p < 0) || (sd_p < 0))
  {
    fprintf(stderr, "Error: Socket creation failed\n");
    exit(EXIT_FAILURE);
  }

  /* ALLOW REUSE OF PORTS - AVOID "BIND FAILED" ISSUES */
  if (setsockopt(sd_p, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0)
  {
    fprintf(stderr, "Error: Setting participant connection socket option failed\n");
    exit(EXIT_FAILURE);
  }
  if (setsockopt(sd_o, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0)
  {
    fprintf(stderr, "Error: Setting observer connection socket option failed\n");
    exit(EXIT_FAILURE);
  }

  /* TODO(socketBind): Bind a local address to the socket. For this, you need to pass correct parameters to the bind function. */
  if (bind(sd_p, (struct sockaddr *)&sad_p, sizeof(sad_p)) < 0)
  {
    fprintf(stderr, "Error: Bind failed\n");
    exit(EXIT_FAILURE);
  }
  if (bind(sd_o, (struct sockaddr *)&sad_o, sizeof(sad_o)) < 0)
  {
    fprintf(stderr, "Error: Bind failed\n");
    exit(EXIT_FAILURE);
  }

  /* TODO(socketListen): Specify size of request queue. Listen take 2 parameters -- socket descriptor and QLEN, which has been set at the top of this code. */
  if ((listen(sd_p, QLEN) < 0) || (listen(sd_o, QLEN) < 0))
  {
    fprintf(stderr, "Error: Listen failed\n");
    exit(EXIT_FAILURE);
  }
}

/* Valid Arguments Checker
 *
 * Makes sure the command line arguments entered are valid for this program.
 */
int validArguments(const int numArgs, char **args) {
  int argsValid = TRUE;
  if (numArgs != 3) {
    fprintf(stderr, "Usage: ./server_program participant_port observer_port\n");
    argsValid = FALSE;
  }
  return argsValid;
}

/* Max of 2 Integers
 *
 * Finds the max of the 2 inputs and returns it
 */
 int max2ints(int a, int b) {
   int max;
   if (a >= b) {
     max = a;
   } else {
     max = b;
   }
   return max;
 }

/***************** LINKED LIST CODE *****************/

/* Create Node
 * username   The username associated with the connection
 * fd         The file descriptor associated with the users connection
 *
 * Allocates memory for a node of type struct nodeStruct and initializes
 * it with the value item. Returns a pointer to the new node.
 */
struct ConnectionStatsNode* createConnNode(char* username, int fd) {
  struct ConnectionStatsNode *node = malloc(sizeof(struct ConnectionStatsNode));
  node->username = username;
  node->socket = fd;
  node->next = NULL;
  return node;
}

/* Insert Head
 * headRef    Pointer to the head of the list.
 * node    Pointer to the node to be inserted.
 *
 * Inserts node at the head of the list.
 */
void insertHead_connList (struct ConnectionStatsNode** headRef, struct ConnectionStatsNode* node) {
    if(headRef == NULL){
        headRef = &node;
        (*headRef) = node;
    }else{
        node->next = *headRef;
        *headRef = node;
    }
    return;
}


/* Remove Node
 * headRef    Pointer to the head of the list.
 * node    Pointer to the node to be removed.
 *
 * Delete node from the list and free memory allocated to it.
 * This function assumes that node has been properly set to a valid node in the list.
 * For example, the client code may have found it by calling List_findNode().
 * If the list contains only one node, the head of the list should be set to NULL.
 */
void deleteNode_connList (struct ConnectionStatsNode** headRef, struct ConnectionStatsNode* node) {
    int deleted = 0;
    if(*headRef == node){
        *headRef = node->next;
         free(node);
    }else{
        while(((*headRef)->next != NULL) && !deleted){
            if((*headRef)->next == node){
                (*headRef)->next = node->next;
                free((*headRef)->username);
                free(node);
                deleted = 1;
            }
        }
    }
    return;
}


/* Find Users Socket
 * headRef    Pointer to the head of the list.
 * username   The username being searched for.
 *
 * Given the username of a client, this finds their associated socket.
 * Returns the socket if found, if not found returns -1.
 */
int findUserSocket(struct ConnectionStatsNode** headRef, char* username) {
  int socket = -1;
  if (headRef != NULL){
    while ((*headRef) != NULL) {
      printf("%d, ", socket);
      if (strcmp((*headRef)->username, username) == 0) {
        socket = (*headRef)->socket;
      } else {
        (*headRef) = (*headRef)->next;
      }
    }
  }
  return socket;
}


/* Delete List
 * headRef    Pointer to the head of the list.
 *
 * Delete all nodes from the list and free memory allocated to the nodes.
 */
void deleteList_connList (struct ConnectionStatsNode** headRef) {
  struct ConnectionStatsNode* temp;
  while ((*headRef) != NULL) {
    temp = (*headRef);
    (*headRef)->next = (*headRef);
    free(temp->username);
    free(temp);
  }
  return;
}
