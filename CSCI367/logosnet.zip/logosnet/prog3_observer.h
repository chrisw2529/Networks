
/* Ryan Lingg, Chris White
 * CSCI 367 Computer Networks 1
 * Project 3: LogosNet
 * 11/27/18
 * prog3_observer.h
 */

#ifndef PROG3_OBSERVER_H
#define PROG3_OBSERVER_H

/* INCLUDED LOCAL UTILITY FILES */

/* STRUCTURE DEFINITIONS */

/* FUNCTION PROTOTYPES */

// Communication Helpers:

// Connection Helpers:
void initSocketAndConnect(int argc, char **argv);
int validArguments(const int numArgs, char **args);

#endif