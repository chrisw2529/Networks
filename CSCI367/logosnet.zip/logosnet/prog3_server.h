
/* Ryan Lingg, Chris White
 * CSCI 367 Computer Networks 1
 * Project 3: LogosNet
 * 11/27/18
 * prog3_server.h
 */

#ifndef PROG3_SERVER_H
#define PROG3_SERVER_H

/* INCLUDED LOCAL UTILITY FILES */

/* STRUCTURE DEFINITIONS */
struct ConnectionStatsNode {
  struct ConnectionStatsNode* next;
  char* username;
  int socket;
};

/* FUNCTION PROTOTYPES */

// Communication Helpers:
char validUsername();
int getChatterUsername(int sd_temp);

// Connection Helpers:
void initSocketsAndListen(char **argv);
int validArguments(const int numArgs, char **args);
void connectChatter();

void clearMessageBuf();
void checkTransmissionError(char* message);
void errorMessageAndExit(char* message);

// Linked List:
struct ConnectionStatsNode* createConnNode(char* username, int fd);
void insertHead_connList (struct ConnectionStatsNode** headRef, struct ConnectionStatsNode* node);
void deleteNode_connList (struct ConnectionStatsNode** headRef, struct ConnectionStatsNode* node);
int findUserSocket(struct ConnectionStatsNode** headRef, char* username);
void deleteList_connList (struct ConnectionStatsNode** headRef);

// Random Others:
 int max2ints(int a, int b);


#endif
