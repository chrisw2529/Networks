
/* Ryan Lingg, Chris White
 * CSCI 367 Computer Networks 1
 * Project 3: LogosNet
 * 11/27/18
 * prog3_participant.h
 */

#ifndef PROG3_PARTICIPANT_H
#define PROG3_PARTICIPANT_H

/* INCLUDED LOCAL UTILITY FILES */

/* STRUCTURE DEFINITIONS */

/* FUNCTION PROTOTYPES */

// Communication Helpers:
void sendGuessToServer();
void enterUsernameBeforeTimeIsUp();



// Connection Helpers:
void initSocketAndConnect(int argc, char **argv);
int validArguments(const int numArgs, char **args);
void errorMessageAndExit(char* message);
void checkTransmissionError(char* message);


#endif
