
/* Ryan Lingg, Chris White
* CSCI 367 Computer Networks 1
* Project 3: LogosNet
* 11/27/18
* prog3_participant.c
*/

#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>

#include "prog3_participant.h"

/* Macro Definitions */
#define FALSE 0   /* boolean replacement */
#define TRUE 1	/* boolean replacement */
#define BLEN 1000 /* message buffer length */

/* Global Connection Parameters */
struct hostent *ptrh;   /* pointer to a host table entry */
struct protoent *ptrp;  /* pointer to a protocol table entry */
struct sockaddr_in sad; /* structure to hold an IP address */
int sd;					/* socket descriptor */
int port;				/* protocol port number */
char *host;				/* pointer to host name */
int n;					/* number of characters read */
char buf[BLEN];			/* buffer for data from the server */
int username_timeout = 10; /*amount of time a user has to enter their username (seconds)*/



int main(int argc, char **argv)
{
    char c;

	// TODO(validArguments): Check command line arguments
  if (validArguments(argc, argv) == FALSE) {
    exit(EXIT_FAILURE);
  }

	// Initialize the socket structure and connect to the chat server
	initSocketAndConnect(argc, argv);


	// Negotiate unique username
	//     (loop until Recieve y from server or disconnect, send username attempts)

  enterUsernameBeforeTimeIsUp();
  printf("\n");
  while (1) {
    n = recv(sd, &c, sizeof(c), 0);
    printf("%c", c);
    fflush(stdout);
    if (n <= 0) {
      break;
    }
  }
	// Send and Recieve Messages
}



//promps user to enter a username
void enterUsernameBeforeTimeIsUp() {
	struct timeval timeout;
  fd_set input_set;
  int receivedMessage;

  // Set input fd to receiving stdin
  FD_ZERO(&input_set);
  FD_SET(fileno(stdin), &input_set);

  // Set timeout limit
  timeout.tv_sec = username_timeout;
  timeout.tv_usec = 0;

	fprintf(stdout, "Enter Username: ");
	fflush(stdout);
  memset(buf, 0, sizeof(buf));
	// Listen for input stream activity
  receivedMessage = select(fileno(stdin)+1, &input_set, NULL, NULL, &timeout);

	if (receivedMessage == -1) {
    errorMessageAndExit("Error in select.");
  } else if (receivedMessage == 0) {
		fprintf(stdout, "Empty string entered.");
	} else {
    //Read Input:
		n = read(fileno(stdin), buf, BLEN);
		if (n < 0) {
			errorMessageAndExit("Error in read input.");
		} else if (n == 1) {
			fprintf(stdout, "Only hit enter. You is dumb.\n");
		} else {
			if (buf[n-1] == '\n') {
				buf[n-1] = '\0';
				n--;
			}
		}
		sendGuessToServer();
		FD_CLR(fileno(stdin)+1, &input_set);
	}
  checkTransmissionError("Transmission Error: Reading guess error in guessBeforeTimeIsUp.");
	fflush(stdout);
}


void sendGuessToServer() {
	uint8_t len_send = (uint8_t)n;
	send(sd, &len_send, sizeof(len_send), 0);
	send(sd, &buf, (size_t)len_send, 0);
}

void errorMessageAndExit(char* message) {
	fprintf(stderr, "Error: %s\n", message);
	close(sd);
	exit(EXIT_FAILURE);
}

void checkTransmissionError(char* message) {
	if (n < 0){
		errorMessageAndExit(message);
	}
}


void getConnectedMessage() {
	char validUsername;
	// uint8_t numLetters;
	// uint8_t numSeconds;

	//Getting player number
	n = recv(sd, &validUsername, sizeof(validUsername), 0);
	checkTransmissionError("Transmission Error: Bad playerNum in getConnectedMessage.");
	if (validUsername == 'Y') {
	    printf("the server replied with a 'Y' username is valid\n");
	} else if (validUsername == 'N') {
	    printf("Username is not valid try again\n");
	} else {
	    errorMessageAndExit("Recieved invaid server username responce (not a 'Y' or 'N').");
	}

	// //Getting the board size
  // n = recv(sd, &numLetters, sizeof(numLetters), 0);
	// checkTransmissionError("Transmission Error: Bad board_size in getConnectedMessage.");
  // board_size = (int)numLetters;
  // printf("Board size: %d\n", board_size);
  //
	// //Getting the seconds per turn
	// n = recv(sd, &numSeconds, sizeof(numSeconds), 0);
	// checkTransmissionError("Transmission Error: Bad turn_length in getConnectedMessage.");
	// turn_length = (int)numSeconds;
	// printf("Seconds per turn: %d\n", turn_length);
	// fflush(stdout);

}



/* Initialize Socket and Connect to Server
 *
 * Fills all the fields of the socket structure and connects to the server.
 */
void initSocketAndConnect(int argc, char **argv)
{
	memset((char *)&sad, 0, sizeof(sad)); /* clear sockaddr structure */
	sad.sin_family = AF_INET;			  /* set family to Internet */

	port = atoi(argv[2]); /* convert to binary */
	if (port > 0)
	{ /* test for legal value */
		sad.sin_port = htons((u_short)port);
	}
	else
	{
		fprintf(stderr, "Error: bad port number %s\n", argv[2]);
		exit(EXIT_FAILURE);
	}

	host = argv[1]; /* if host argument specified */

	/* Convert host name to equivalent IP address and copy to sad. */
	ptrh = gethostbyname(host);
	if (ptrh == NULL)
	{
		fprintf(stderr, "Error: Invalid host: %s\n", host);
		exit(EXIT_FAILURE);
	}

	memcpy(&sad.sin_addr, ptrh->h_addr, ptrh->h_length);

	/* Map TCP transport protocol name to protocol number. */
	if (((long int)(ptrp = getprotobyname("tcp"))) == 0)
	{
		fprintf(stderr, "Error: Cannot map \"tcp\" to protocol number");
		exit(EXIT_FAILURE);
	}

	/* Create a socket. */
	sd = socket(PF_INET, SOCK_STREAM, ptrp->p_proto);
	if (sd < 0)
	{
		fprintf(stderr, "Error: Socket creation failed\n");
		exit(EXIT_FAILURE);
	}

	/* TODO(connect): Connect the socket to the specified server. You have to pass correct parameters to the connect function.*/
	if (connect(sd, (struct sockaddr *)&sad, sizeof(sad)) < 0)
	{
		fprintf(stderr, "connect failed\n");
		exit(EXIT_FAILURE);
	}
}

/* Valid Arguments Checker
 *
 * Makes sure the command line arguments entered are valid for this program.
 */
int validArguments(const int numArgs, char **args)
{
	int argsValid = TRUE;
	if (numArgs != 3)
	{
		fprintf(stderr, "Usage: ./participant_program server_ip participant_port\n");
		argsValid = FALSE;
	}
	return argsValid;
}
